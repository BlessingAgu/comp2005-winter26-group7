
import java.awt.*;
import javax.swing.*;


public class setUpGame extends JFrame{
   
    //player counter
    private int numberOfPlayers;
    private Player[] players = new Player[4];
    private JButton player1Button;
    private JButton player2Button;
    private JButton player3Button;
    private JButton player4Button;
   
   
    public setUpGame(){
        numberOfPlayers = 1; // keeping player count tracked

        players[0] = new Player(1, true); //PLAYER 1 ALWAYS HUMAN TO START
       
        setTitle("Game Set Up");
        setSize(800, 800);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new GridBagLayout()); //setting Layout of the UI to be able to modifly to fit the size of players allowed in
        GridBagConstraints gbc = new GridBagConstraints();
       
       
       
        //adding the Back and the start game buttons
        JButton back = new JButton("Main Menu");
        gbc.gridx = 0;
        gbc.gridy = 0;
        add(back, gbc);
       
       
       
        back.addActionListener(e -> {
           
            //mainMenu(); meant to return players to the main menu once it is implimented
           
           
        });
       
       
        JButton start = new JButton("Start Game");
        gbc.gridx = 10;
        gbc.gridy = 0;
        add(start, gbc);
       
        start.addActionListener(e -> {
           
            new BlokusGame(20, players, numberOfPlayers);
           
           
       
           
        });
       
        player1Button = new JButton("Player 1");
        gbc.gridx = 0;
        gbc.gridy = 10;
        add(player1Button, gbc);
       
        player2Button = new JButton("Player 2");
        gbc.gridx = 10;
        gbc.gridy = 10;
        add(player2Button, gbc);
        player2Button.setVisible(false);
       
        player3Button = new JButton("Player 3");
        gbc.gridx = 0;
        gbc.gridy = 20;
        add(player3Button, gbc);
        player3Button.setVisible(false);
       
        player4Button = new JButton("Player 4");
        gbc.gridx = 10;
        gbc.gridy = 20;
        add(player4Button, gbc);
        player4Button.setVisible(false);
       
        JButton addPlayerButton = new JButton("Add Player");
        gbc.gridx = 0;
        gbc.gridy = 30;
        add(addPlayerButton, gbc);


        addPlayerButton.addActionListener(e -> {
            playerTypeMenu();

        });
       
        JButton removePlayerButton = new JButton("Remove Player");
        gbc.gridx = 10;
        gbc.gridy = 30;
        add(removePlayerButton, gbc);
       
        JButton optionsButton = new JButton("Options");
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0;
        gbc.gridy = 40;
        gbc.gridwidth = 50;
        gbc.ipady = 40;
        gbc.weightx = 0.0;
        add(optionsButton, gbc);
       
        optionsButton.addActionListener(e -> {
            new OptionsMenu();
           
        });
       
        setLocationRelativeTo(null); // puts it right in the middle of the screen
        setVisible(true);
       
       
    }
   
    public void addPlayer(){
        if (numberOfPlayers == 4) {
            //tooManyPlayers();
        }
        else {
            if (numberOfPlayers == 0) {
                //Player p1 = new Player();


               
                }
            else if (numberOfPlayers == 1) {
                //Player p2 = new Player();
                player2Button.setVisible(true);
                numberOfPlayers++;


            }
            else if (numberOfPlayers == 2) {
                //Player p3 = new Player();
                player3Button.setVisible(true);
                numberOfPlayers++;

            }
            else if (numberOfPlayers == 3) {
            //Player p4 = new Player();
            player4Button.setVisible(true);
            numberOfPlayers++;
        }

        
        }
        
       
    }
   
    public void changePlayerColor() {
       
        JFrame colorPicker = new JFrame("color selection");
        colorPicker.setSize(400, 200);
        colorPicker.setLayout(new BoxLayout(colorPicker.getContentPane(), BoxLayout.Y_AXIS));
       
        //creating the menu to pick color from
        JButton color1B = new JButton("");
        color1B.setBackground(Color.RED);
       
        color1B.addActionListener(e -> {
            //changePlayerColour()
           
        });
       
        JButton color2B = new JButton("");
        color2B.setBackground(Color.GREEN);
       
        color2B.addActionListener(e -> {
            //changePlayerColour()
           
        });
       
        JButton color3B = new JButton("");
        color3B.setBackground(Color.BLUE);
       
        color3B.addActionListener(e -> {
            //changePlayerColour()
           
        });
       
        JButton color4B = new JButton("");
        color4B.setBackground(Color.YELLOW);
       
        color4B.addActionListener(e -> {
            //changePlayerColour()
           
        });
       
       
    }
   
    public void playerTypeMenu() {
        JFrame playerType = new JFrame("Choose Player type"); // pops up a menu to chose a player type
        playerType.setSize(600, 750);
        playerType.setLayout(new BoxLayout(playerType.getContentPane(), BoxLayout.Y_AXIS));
       
        JButton compPlayer = new JButton("Computer Player");
        compPlayer.setFont(new Font("Arial", Font.PLAIN, 18));
        compPlayer.setAlignmentX(Component.CENTER_ALIGNMENT);
       
        compPlayer.addActionListener(e -> {
           
            JFrame difficultyFrame = new JFrame("Choose Difficulty");
            difficultyFrame.setSize(400, 300);
            difficultyFrame.setLayout(new BoxLayout(difficultyFrame.getContentPane(), BoxLayout.Y_AXIS));

            JButton easyButton = new JButton("Easy");
            easyButton.setFont(new Font("Arial", Font.PLAIN, 18));
            easyButton.setAlignmentX(Component.CENTER_ALIGNMENT);

            JButton hardButton = new JButton("Hard");
            hardButton.setFont(new Font("Arial", Font.PLAIN, 18));
            hardButton.setAlignmentX(Component.CENTER_ALIGNMENT);

            easyButton.addActionListener(a -> {
            players[numberOfPlayers] = new ComputerPlayer(numberOfPlayers + 1, "Easy", null);
            addPlayer(); 
            playerType.dispose();
            difficultyFrame.dispose();
        });

            hardButton.addActionListener(a -> {
            players[numberOfPlayers] = new ComputerPlayer(numberOfPlayers + 1, "Hard", null);
            addPlayer();
            playerType.dispose();
            difficultyFrame.dispose();
        });

        difficultyFrame.add(easyButton);
        difficultyFrame.add(hardButton);
        difficultyFrame.setLocationRelativeTo(null);
        difficultyFrame.setVisible(true);
           
           
        });
       
        JButton humanPlayer = new JButton("Human Player");
        humanPlayer.setFont(new Font("Arial", Font.PLAIN, 18));
        humanPlayer.setAlignmentX(Component.CENTER_ALIGNMENT);
       
        humanPlayer.addActionListener(e -> {
            
            players[numberOfPlayers] = new Player(numberOfPlayers + 1, true);
            addPlayer();
            playerType.dispose();
           
        });
        playerType.add(compPlayer);
        playerType.add(humanPlayer);
        playerType.setVisible(true);
    }
   
    public void tooManyPlayers() { //convert to it's own class later for error handling
       
    }  
   
    public int getNumberOfPlayers() { //getter for number of players
        return numberOfPlayers;
    }

    

}

