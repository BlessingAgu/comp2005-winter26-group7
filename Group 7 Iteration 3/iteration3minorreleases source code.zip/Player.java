import java.awt.Color;

public class Player {

    private int playerNumber;
    private boolean isHuman;
    private String difficulty = "Easy"; // default

    public Player(int playerNumber, boolean isHuman) {
        this.playerNumber = playerNumber;
        this.isHuman = isHuman;
    }

    public int getPlayerNumber() {
        return playerNumber;
    }

    public boolean isHuman() {
        return isHuman;
    }

    public String getDifficulty() {
        return difficulty;
    }

    public void setDifficulty(String difficulty) {
        this.difficulty = difficulty;
    }

    public Color getPlayerColor() {
        return BoardSquareColors.getColorForPlayer(playerNumber);
    }
}
