import java.util.ArrayList;
import java.util.Random;

public class ComputerPlayer extends Player {

    private Random random = new Random(); // for choosing random position on the board when i code it
    public BlokusGame game; // reference to the game board so we can read state and place pieces

    public ComputerPlayer(int playerNumber, String difficulty, BlokusGame game) {
        super(playerNumber, false); // always not human
        setDifficulty(difficulty);
        this.game = game; // save the game reference so the methods below can use it
    }

    // called when it's the computer player's turn, checks the difficulty and calls the right method
    public void takeTurn() {
        if (getDifficulty().equals("Easy")) {
            easyMove();
        } else {
            hardMove();
        }
    }

    // not void because it needs to return the list back to whenever its called
    private ArrayList<int[]> getValidMoves() { 
        // creates a list to store all valid moves
        // each move is stored as {row, col, rotation}
        ArrayList<int[]> moves = new ArrayList<>();

        // loop through every square on the board (20x20 = 400 squares)
        for (int row = 0; row < game.boardSize; row++) {
            for (int col = 0; col < game.boardSize; col++) {

                // for each square, try all 4 rotations of the piece
                // important because it might not fit one way but fits another
                for (int rot = 0; rot < 4; rot++) {
                    game.pieceRotation = rot; // set the rotation in the game

                    // getPieceShape() uses whatever piece and rotation is currently set in the game
                    // it returns the shape as a list of squares relative to the top left corner
                    int[][] shape = game.getPieceShape();

                    // canPlacePiece checks the Blokus rules:
                    // 1. piece fits on board and doesn't overlap
                    // 2. first piece must cover starting corner
                    // 3. must touch own piece diagonally, not on the side (not flush)
                    if (game.canPlacePiece(row, col, shape)) {
                        // legal move found, store the row, col, and rotation together
                        moves.add(new int[]{row, col, rot});
                    }
                }
            }
        }
        return moves; // returns the list to be used by other methods (easyMove and hardMove)
    }

    // takes the list of valid moves and picks one at random to place
    // passing in chosenPieceIndex so it knows which piece it's placing
    private void placeRandomMove(ArrayList<int[]> moves, int chosenPieceIndex) {
        // pick a random valid move
        if (moves.size() > 0) {
            // pick a random index number between 0 and however many moves we found
            int randomChoice = random.nextInt(moves.size());
            
            // grab the chosen move's data, it's row, column, and rotation
            int[] chosenMove = moves.get(randomChoice);
            int chosenRow = chosenMove[0];
            int chosenCol = chosenMove[1];
            int chosenRot = chosenMove[2];

            // make sure the right piece and rotation are set in the game before getting the shape
            // without this, getPieceShape() might return the wrong shape
            game.selectedPieceIndex = chosenPieceIndex;
            game.selectedPieceType = BlokusGame.PIECE_IDS[chosenPieceIndex];
            game.pieceRotation = chosenRot;

            // gets the final shape with the correct piece and rotation set
            int[][] finalShape = game.getPieceShape();

            // loop through each square of the piece shape and color it on the board
            // sq[0] is the row offset, sq[1] is the col offset from the chosen position
            // basically: relative to where has been clicked, also fill in the remaining squares of the piece
            for (int[] sq : finalShape) {
                int r = chosenRow + sq[0];
                int c = chosenCol + sq[1];

                // color the square with the computer player's color
                game.boardSquares[r][c].setPlayer(getPlayerNumber());

                // lock the square so nobody can click it again
                game.boardSquares[r][c].setEnabled(false);
            }
        }
    }

    // updates all the game state after the computer places a piece
    private void updateGameState(int pIndex, int chosenPieceIndex) {

        // update game state to end turn
        game.piecesUsed[pIndex][chosenPieceIndex] = true; // piece is used
        game.hasPlacedFirstPiece[pIndex] = true; // so it checks off that it touched the corner
        game.pieceRotation = 0; // reset rotation back to default

        // goes to the next player
        // if player 1 just went 1 % 4 = 1, then 1+1 = 2, player 2 goes next.
        // if player 3 just went, 3 % 4 = 3, then 3+1 = 4, so player 4 goes next.
        game.currentPlayer = (game.currentPlayer % 4) + 1;

        // reset piece selection and refresh buttons for next player (so it isn't using the last piece the computer player used)
        game.selectedPieceIndex = 0;
        game.selectedPieceType = BlokusGame.PIECE_IDS[0];
        game.updatePieceButtons();
    }

    // EASY - smallest piece first, random legal position
    private void easyMove() {
        // grabbing player number, minus 1 because of how it's stored, index 0 is player 1
        int pIndex = getPlayerNumber() - 1;

        // loop forward through pieces (0 to 20), it's sorted already so index 0 is the smallest piece
        // find the first smallest piece that hasn't been used yet
        int chosenPieceIndex = -1;
        for (int i = 0; i < 21; i++) {
            if (!game.piecesUsed[pIndex][i]) {
                chosenPieceIndex = i;
                break;
            }
        }

        if (chosenPieceIndex == -1) return; // no pieces remaining, do nothing

        // updates the game to say this piece is selected
        game.selectedPieceIndex = chosenPieceIndex;
        game.selectedPieceType = BlokusGame.PIECE_IDS[chosenPieceIndex];

        // get all legal positions for this piece (put into a list)
        ArrayList<int[]> validMoves = getValidMoves(); 
        
        // if there are legal moves, place one randomly and update the game state
        if (validMoves.size() > 0) {
            placeRandomMove(validMoves, chosenPieceIndex); 
            updateGameState(pIndex, chosenPieceIndex); // tell the game which player and piece just went
        }
    }
    

    // HARD - biggest piece first, random legal position
    private void hardMove() {
        int pIndex = getPlayerNumber() - 1;
        int chosenPieceIndex = -1;

        // loop backwards (20, 19, 18...) to find the biggest piece that hasn't been used yet
        // this is because in BlokusGame the list of pieces is already sorted, index 0 is smallest, index 20 is largest.
        for (int i = 20; i >= 0; i--) {
            if (!game.piecesUsed[pIndex][i]) {
                chosenPieceIndex = i;
                break;
            }
        }

        if (chosenPieceIndex == -1) return;

        game.selectedPieceIndex = chosenPieceIndex;
        game.selectedPieceType = BlokusGame.PIECE_IDS[chosenPieceIndex];

        // exact same as easy move
        ArrayList<int[]> validMoves = getValidMoves(); 
        
        if (validMoves.size() > 0) {
            placeRandomMove(validMoves, chosenPieceIndex);
            updateGameState(pIndex, chosenPieceIndex); 
        }
    }
}
