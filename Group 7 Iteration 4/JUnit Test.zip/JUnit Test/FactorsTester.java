import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.Arrays;

import org.junit.jupiter.api.Test;

class FactorsTester {

	/*@Test
	void testPerfect1()
	{	
		// TEST 1: should throw the exception because the parameter value is less than 1
		assertThrows(IllegalArgumentException.class, () -> FactorsUtility.perfect(0));
	}
	
	@Test
	void testPerfect2()
	{	
		// TEST 2: should succeed because 1 is a valid parameter value, but is not a perfect number
		assertFalse(FactorsUtility.perfect(1));
	}
	
	@Test
	void testPerfect3()
	{	
		// TEST 3: should succeed because 6 is a valid parameter value, and is a perfect number
		assertTrue(FactorsUtility.perfect(6));
	}
	
	@Test
	void testPerfect4()
	{	
		// TEST 4: should succeed because 7 is a valid parameter value, but is not a perfect number
		// I've coded this using assertEquals to show that there's often more than one way to write a test 
		boolean expected = false;
		assertEquals(expected, FactorsUtility.perfect(7));
	}*/
	
	@Test
	void testgetFactors1() {
		assertThrows(IllegalArgumentException.class, () -> FactorsUtility.getFactors(-1)); //-1 throws exception
	}
	
	@Test
	void testgetFactors2() {
		
		ArrayList<Integer> factors = new ArrayList<Integer>(); //factors  has empty list here
		assertEquals(factors, FactorsUtility.getFactors(0)); // getFactors(0) should return empty list[]
	}
	
	@Test
	void testgetFactors3() {
		
		ArrayList<Integer> factors = new ArrayList<Integer>(); // empty list
		assertEquals(factors, FactorsUtility.getFactors(1)); // getFactors(1) should return empty list[]
	}
	
	@Test
	void testgetFactors4() {
		
		ArrayList<Integer> factors = new ArrayList<Integer>(Arrays.asList(1,2,3,4,6));
		assertEquals(factors, FactorsUtility.getFactors(12)); // getFactors(12) should return [1,2,3,4,6]
	}
	
	@Test
	void testgetFactors5() {
		ArrayList<Integer> factors = new ArrayList<Integer>(Arrays.asList(1)); //assigns 1
		assertEquals(factors, FactorsUtility.getFactors(2)); // getFactors(1) should return [1]
	}
	
	@Test
	void testFactors1() {
		assertThrows(IllegalArgumentException.class, () -> FactorsUtility.factor(1,0)); // b <1 throws exception
	}
	
	@Test
	void testFactors2() {
		assertThrows(IllegalArgumentException.class, () -> FactorsUtility.factor(-1,1)); // a < 0 throws exception
	}
	
	@Test
	void testFactors3() {
		boolean expected = true;
		assertEquals(expected, FactorsUtility.factor(4,2)); // b is a factor of a
	}
	
	@Test
	void testFactors4() {
		boolean expected = false;
		assertEquals(expected, FactorsUtility.factor(4,3)); // b is not a factor of a
	}
	
	@Test
	void testFactors5() {
		boolean expected = true;
		assertEquals(expected, FactorsUtility.factor(0,4)); // b is a factor of a
	}
}
