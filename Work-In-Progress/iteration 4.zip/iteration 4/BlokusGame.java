import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/**
 * 
 * @author Group7
 */
public class BlokusGame extends JFrame implements ActionListener
{
	// GUI components
	private JPanel topPanel, piecePanel;
	public JLabel statusLabel;
	private JButton newGameButton;
	public BoardSquare[][] boardSquares;
	private JButton[] pieceButtons;
	public int boardSize;

	// Game state
	public int currentPlayer;
	boolean gameActive;
	public boolean[] hasPlacedFirstPiece;
	public boolean[][] piecesUsed;
	private int[][] startingCorners;

	// stores players from setUpGame so we know who is human and who is computer
	public Player[] players;
	public int numberOfPlayers;

	// Player names
	String[] playerNames;

	//player colors
	public int[] colorOwners;

	// Current selection
	public int selectedPieceIndex;
	public String selectedPieceType;
	public int pieceRotation;
	public boolean pieceFlipped;

	// Preview
	private int previewRow = -1;
	private int previewCol = -1;

	// track consecutive passes
	int consecutivePasses = 0;
	public boolean[] lastPieceWasMono;

	// Piece data
	public static final String[] PIECE_IDS = {
		"I1","I2","I3","V3","I4","O","T","L4","Z4",
		"F","I5","L","N","P","T5","U","V","W","X","Y","Z"
	};

	private static final String[] PIECE_NAMES = {
		"■ (1sq)","■■ (2sq)","■■■ (3sq)","■■(L) (3sq)",
		"■■■■ (4sq)","■■(2x2) (4sq)","■■■(T) (4sq)","■(L) (4sq)","■■(Z) (4sq)",
		"F (5sq)","■■■■■ (5sq)","L (5sq)","N (5sq)","P (5sq)",
		"T (5sq)","U (5sq)","V (5sq)","W (5sq)","X (5sq)","Y (5sq)","Z (5sq)"
	};

	public BlokusGame(int boardSize)
	{
		this(boardSize, new String[]{"Player 1","Player 2","Player 3","Player 4"}, 4, null, null);
	}

	public BlokusGame(int boardSize, String[] playerNames)
	{
		this(boardSize, playerNames, 4, null, null);
	}

	public BlokusGame(int boardSize, Player[] players, int numberOfPlayers)
	{
		this(boardSize, buildPlayerNames(numberOfPlayers), numberOfPlayers, players, null);
	}

	public BlokusGame(int boardSize, Player[] players, int numberOfPlayers, int[] colorOwners)
	{
		this(boardSize, buildPlayerNames(numberOfPlayers), numberOfPlayers, players, colorOwners);
	}

	public BlokusGame(GameSaveState state)
	{
		this(state.boardSize, state.playerNames, state.numberOfPlayers, null, null);
		restoreState(state);
	}

	private BlokusGame(int boardSize, String[] names, int numberOfPlayers, Player[] players, int[] customColorOwners)
	{
		this.boardSize       = boardSize;
		this.numberOfPlayers = Math.max(numberOfPlayers, 1);
		this.players         = players;
		this.playerNames     = (names != null && names.length == numberOfPlayers)
		                       ? names : buildPlayerNames(numberOfPlayers);

		currentPlayer     = 1;
		gameActive        = false;
		hasPlacedFirstPiece = new boolean[4];
		piecesUsed        = new boolean[4][21];
		selectedPieceIndex = 0;
		selectedPieceType  = PIECE_IDS[0];
		pieceRotation     = 0;
		pieceFlipped      = false;

		//initialise tracking arrays
		lastPieceWasMono  = new boolean[4];
		consecutivePasses = 0;

		startingCorners    = new int[4][2];
		startingCorners[0] = new int[]{0,           0           };
		startingCorners[1] = new int[]{0,           boardSize-1 };
		startingCorners[2] = new int[]{boardSize-1, boardSize-1 };
		startingCorners[3] = new int[]{boardSize-1, 0           };

		if (customColorOwners != null)
			this.colorOwners = customColorOwners;
		else
			setupColorOwnership();

		if (players != null)
		{
			for (int i = 0; i < numberOfPlayers; i++)
				if (players[i] != null && !players[i].isHuman())
					((ComputerPlayer) players[i]).game = this;
		}

		GameUI.setGameWindow(this);
		setupGUI();

		pack();
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setTitle("Blokus");
		setResizable(false);
		setLocationRelativeTo(null);
		setVisible(true);

		// check if app crashed mid-scoring last session
		ScoreCheckpoint.resumeIfPresent(this);
	}

	private void setupColorOwnership()
	{
		colorOwners = new int[4];
		switch (numberOfPlayers)
		{
			case 2:
				colorOwners[0] = 0; colorOwners[1] = 1;
				colorOwners[2] = 0; colorOwners[3] = 1;
				break;
			case 3:
				colorOwners[0] = 0; colorOwners[1] = 1;
				colorOwners[2] = 2; colorOwners[3] = 0;
				break;
			default:
				for (int i = 0; i < 4; i++) colorOwners[i] = Math.min(i, numberOfPlayers - 1);
		}
	}

	public int getColorOwnerIdx(int colorNumber)
	{
		return (colorOwners != null) ? colorOwners[colorNumber - 1] : colorNumber - 1;
	}

	public Player getPlayerForColor(int colorNumber)
	{
		if (players == null) return null;
		int ownerIdx = getColorOwnerIdx(colorNumber);
		return (ownerIdx < players.length) ? players[ownerIdx] : null;
	}

	public String getColorDisplayName(int colorNumber)
	{
		int ownerIdx = getColorOwnerIdx(colorNumber);
		String ownerName = (ownerIdx < playerNames.length)
		                   ? playerNames[ownerIdx]
		                   : "Player " + (ownerIdx + 1);
		if (numberOfPlayers < 4)
			return ownerName + " (Color " + colorNumber + ")";
		return ownerName;
	}

	public void triggerComputerTurnIfNeeded()
	{
		if (!gameActive) return;
		Player next = getPlayerForColor(currentPlayer);
		if (next != null && !next.isHuman())
		{
			Timer timer = new Timer(450, e -> {
				if (gameActive) ((ComputerPlayer) next).takeTurn();
			});
			timer.setRepeats(false);
			timer.start();
		}
	}

	private void setupGUI()
	{
		topPanel   = new JPanel(new FlowLayout(FlowLayout.LEFT));
		piecePanel = new JPanel(new GridLayout(21, 1, 2, 2));
		piecePanel.setPreferredSize(new Dimension(155, 630));
		JPanel boardPanel = new JPanel(new GridLayout(boardSize, boardSize, 1, 1));

		// core buttons placed on top
		newGameButton = new JButton("New Game");
		JButton rotateButton = new JButton("Rotate");
		JButton flipButton = new JButton("Flip");
		statusLabel = new JLabel("Click 'New Game' to start!");
		JButton passButton = new JButton("Pass Turn");
		JButton saveButton = new JButton("Save Game");
		JButton loadButton = new JButton("Load Game");

		JButton exitButton = new JButton("Exit");

		newGameButton.addActionListener(this);
		rotateButton.addActionListener(e -> rotatePiece());
		flipButton.addActionListener(e -> flipPiece());
		passButton.addActionListener(e   -> passTurn());
		saveButton.addActionListener(e   -> SaveLoadManager.saveGame(this));
		loadButton.addActionListener(e   -> {
			if (SaveLoadManager.loadIntoGame(this))
				statusLabel.setText(getColorDisplayName(currentPlayer) + " - Select piece");
		});
		exitButton.addActionListener(e -> {
			Object[] options = {"Save & Exit", "Exit Without Saving", "Cancel"};
			int choice = JOptionPane.showOptionDialog(
				this,
				"What would you like to do?",
				"Exit Game",
				JOptionPane.YES_NO_CANCEL_OPTION,
				JOptionPane.QUESTION_MESSAGE,
				null, options, options[0]);

			if (choice == 0) {        // Save & Exit
				SaveLoadManager.saveGame(this);
				System.exit(0);
			} else if (choice == 1) { // Exit Without Saving
				System.exit(0);
			}
			// Cancel — do nothing
		});

		topPanel.add(newGameButton);
		topPanel.add(rotateButton);
		topPanel.add(flipButton);
		topPanel.add(passButton);
		topPanel.add(saveButton);
		topPanel.add(loadButton);
		topPanel.add(exitButton);

		// Options button for OptionsMenu (hints and Color Mode)
		try {
			Class.forName("OptionsMenu");
			JButton optionsButton = new JButton("Options");
			optionsButton.addActionListener(e -> new OptionsMenu());
			topPanel.add(optionsButton);
		} catch (ClassNotFoundException e) {
			System.out.println("OptionsMenu not found.");
		}

		topPanel.add(statusLabel);

		pieceButtons = new JButton[21];
		for (int i = 0; i < 21; i++)
		{
			final int idx = i;
			pieceButtons[i] = new JButton(PIECE_NAMES[i]);
			pieceButtons[i].addActionListener(e -> selectPiece(idx));
			pieceButtons[i].setEnabled(false);
			piecePanel.add(pieceButtons[i]);
		}

		boardSquares = new BoardSquare[boardSize][boardSize];
		for (int row = 0; row < boardSize; row++)
		{
			for (int col = 0; col < boardSize; col++)
			{
				boardSquares[row][col] = new BoardSquare(row, col);
				boardSquares[row][col].setPreferredSize(new Dimension(30, 30));
				boardSquares[row][col].setEmpty();
				boardSquares[row][col].setEnabled(false);
				boardSquares[row][col].addActionListener(this);

				final int r = row, c = col;
				boardSquares[row][col].addMouseListener(new MouseAdapter() {
					public void mouseEntered(MouseEvent e) { showPreview(r, c); }
					public void mouseExited (MouseEvent e) { clearPreview(); }
				});

				boardPanel.add(boardSquares[row][col]);
			}
		}

		getContentPane().setLayout(new BorderLayout());
		getContentPane().add(topPanel,   BorderLayout.NORTH);
		getContentPane().add(piecePanel, BorderLayout.WEST);
		getContentPane().add(boardPanel, BorderLayout.CENTER);
	}

	public void actionPerformed(ActionEvent e)
	{
		if (e.getSource() instanceof BoardSquare)
			handleSquareClick((BoardSquare) e.getSource());
		if (e.getSource().equals(newGameButton))
			startNewGame();
	}

	public void startNewGame()
	{
		for (int row = 0; row < boardSize; row++)
		{
			for (int col = 0; col < boardSize; col++)
			{
				boardSquares[row][col].setEmpty();
				boardSquares[row][col].setEnabled(true);
			}
		}

		currentPlayer     = 1;
		gameActive        = true;
		pieceRotation     = 0;
		pieceFlipped      = false;
		consecutivePasses = 0;
		lastPieceWasMono  = new boolean[4];

		for (int i = 0; i < 4; i++)
		{
			hasPlacedFirstPiece[i] = false;
			for (int j = 0; j < 21; j++) piecesUsed[i][j] = false;
		}

		selectedPieceIndex = 0;
		selectedPieceType  = PIECE_IDS[0];

		updatePieceButtons();
		statusLabel.setText(getColorDisplayName(currentPlayer) + " - Select piece");

		// check if next player is a computer, if so take their turn automatically
		triggerComputerTurnIfNeeded();
	}

	// called by GameUI if color palettes are changed
	public void refreshBoardColors()
	{
		for (int row = 0; row < boardSize; row++)
			for (int col = 0; col < boardSize; col++)
				boardSquares[row][col].refreshColor();
	}

	public void updatePieceButtons()
	{
		int playerIdx = currentPlayer - 1;
		for (int i = 0; i < 21; i++)
		{
			if (piecesUsed[playerIdx][i])
			{
				pieceButtons[i].setEnabled(false);
				pieceButtons[i].setText(PIECE_NAMES[i] + " ✗");
			}
			else
			{
				pieceButtons[i].setEnabled(true);
				pieceButtons[i].setText(PIECE_NAMES[i]);
			}
		}
	}

	private void selectPiece(int idx)
	{
		if (!gameActive) return;
		selectedPieceIndex = idx;
		selectedPieceType  = PIECE_IDS[idx];
		statusLabel.setText(getColorDisplayName(currentPlayer) + " selected " + PIECE_NAMES[idx]);
	}

	private void rotatePiece()
	{
		pieceRotation = (pieceRotation + 1) % 4;
		statusLabel.setText(getColorDisplayName(currentPlayer) + " - Rotated " + (pieceRotation * 90) + "°");
	}

	private void flipPiece()
	{
		pieceFlipped = !pieceFlipped;
		statusLabel.setText(getColorDisplayName(currentPlayer) + " - " + (pieceFlipped ? "Flipped" : "Unflipped"));
	}

	private void showPreview(int row, int col)
	{
		if (!gameActive) return;

		if (piecesUsed[currentPlayer - 1][selectedPieceIndex])
			return;

		clearPreview();
		previewRow = row;
		previewCol = col;

		int[][] shape = getPieceShape();
		boolean valid = canPlacePiece(row, col, shape);

		for (int[] sq : shape)
		{
			int r = row + sq[0], c = col + sq[1];
			if (r >= 0 && r < boardSize && c >= 0 && c < boardSize)
			{
				if (valid)
				{
					boardSquares[r][c].setBorder(BorderFactory.createLineBorder(Color.GREEN, 3));
					Color previewColor = getPreviewColor(currentPlayer);
					boardSquares[r][c].setBackground(previewColor);
				}
				else
				{
					boardSquares[r][c].setBorder(BorderFactory.createLineBorder(Color.RED, 3));
				}
			}
		}
	}

	private Color getPreviewColor(int player)
	{
		try {
			Class.forName("BoardSquareColors");
			return BoardSquareColors.getLightColorForPlayer(player);
		} catch (ClassNotFoundException e) {
			switch (player)
			{
				case 1: return new Color(255, 200, 200);
				case 2: return new Color(200, 200, 255);
				case 3: return new Color(200, 255, 200);
				case 4: return new Color(255, 255, 200);
				default: return Color.WHITE;
			}
		}
	}

	private void clearPreview()
	{
		if (previewRow < 0) return;
		for (int row = 0; row < boardSize; row++)
		{
			for (int col = 0; col < boardSize; col++)
			{
				if (boardSquares[row][col].isEmpty())
				{
					boardSquares[row][col].setBorder(BorderFactory.createLineBorder(Color.GRAY, 1));
					boardSquares[row][col].setBackground(Color.WHITE);
				}
			}
		}
		previewRow = -1;
		previewCol = -1;
	}

	private void handleSquareClick(BoardSquare square)
	{
		if (!gameActive || !square.isEnabled()) return;

		int row = square.getRow(), col = square.getCol();

		if (piecesUsed[currentPlayer - 1][selectedPieceIndex])
		{
			statusLabel.setText(getColorDisplayName(currentPlayer) + " - This piece already used! Select a different piece.");
			return;
		}

		int[][] shape = getPieceShape();
		if (!canPlacePiece(row, col, shape)) return;

		for (int[] sq : shape)
		{
			int r = row + sq[0], c = col + sq[1];
			boardSquares[r][c].setPlayer(currentPlayer);
			boardSquares[r][c].setEnabled(false);
		}

		piecesUsed[currentPlayer - 1][selectedPieceIndex] = true;
		hasPlacedFirstPiece[currentPlayer - 1]            = true;
		pieceRotation     = 0;
		pieceFlipped      = false;
		clearPreview();

		//     Track whether this player's last piece was the monomino
		consecutivePasses = 0;
		lastPieceWasMono[currentPlayer - 1] = (selectedPieceIndex == 0);

		if (allPiecesUsed())
		{
			endGame();
			return;
		}

		currentPlayer = (currentPlayer % 4) + 1;
		selectedPieceIndex = 0;
		selectedPieceType  = PIECE_IDS[0];
		updatePieceButtons();
		statusLabel.setText(getColorDisplayName(currentPlayer) + " - Select piece");

		// check if next player is a computer, if so take their turn automatically
		triggerComputerTurnIfNeeded();
	}

	void passTurn()
	{
		if (!gameActive) return;

		consecutivePasses++;
		statusLabel.setText(getColorDisplayName(currentPlayer) + " passed.");

		if (consecutivePasses >= 4)
		{
			endGame();
			return;
		}

		currentPlayer = (currentPlayer % 4) + 1;
		updatePieceButtons();
		statusLabel.setText(statusLabel.getText() + "  |  " +
			getColorDisplayName(currentPlayer) + " - Select piece or Pass Turn");

		triggerComputerTurnIfNeeded();
	}

	// ends game and scores it
	private void endGame()
	{
		gameActive = false;

		for (int row = 0; row < boardSize; row++)
			for (int col = 0; col < boardSize; col++)
				boardSquares[row][col].setEnabled(false);

		statusLabel.setText("Game Over! Calculating scores...");

		ScoreCheckpoint.save(piecesUsed, lastPieceWasMono, buildColorNamesArray());

		try
		{
			Class.forName("ScoringSystem");
			ScoringSystem.showResults(piecesUsed, lastPieceWasMono,
				playerNames, numberOfPlayers, colorOwners, this);
			ScoreCheckpoint.delete();
		}
		catch (ClassNotFoundException e)
		{
			// ScoringSystem not present — basic fallback so game still works
			statusLabel.setText("Game Over! Click 'New Game' to play again.");
			JOptionPane.showMessageDialog(this,
				"Game Over!\nClick 'New Game' to play again.",
				"Game Over",
				JOptionPane.INFORMATION_MESSAGE);
		}
	}

	private String[] buildColorNamesArray()
	{
		String[] arr = new String[4];
		for (int c = 0; c < 4; c++)
		{
			int ownerIdx = colorOwners[c];
			arr[c] = (ownerIdx < playerNames.length)
			         ? playerNames[ownerIdx] + " (Color " + (c + 1) + ")"
			         : "Color " + (c + 1);
		}
		return arr;
	}

	// returns true only when every piece for every player is used.
	private boolean allPiecesUsed()
	{
		for (int p = 0; p < 4; p++)
			for (int i = 0; i < 21; i++)
				if (!piecesUsed[p][i]) return false;
		return true;
	}

	public boolean canPlacePiece(int row, int col, int[][] shape)
	{
		for (int[] sq : shape)
		{
			int r = row + sq[0], c = col + sq[1];
			if (r < 0 || r >= boardSize || c < 0 || c >= boardSize) return false;
			if (!boardSquares[r][c].isEmpty()) return false;
		}

		if (!hasPlacedFirstPiece[currentPlayer - 1])
		{
			int[] corner = startingCorners[currentPlayer - 1];
			for (int[] sq : shape)
			{
				int r = row + sq[0], c = col + sq[1];
				if (r == corner[0] && c == corner[1]) return true;
			}
			return false;
		}

		boolean touchesCorner = false;
		for (int[] sq : shape)
		{
			int r = row + sq[0], c = col + sq[1];
			if (checkDiagonal(r-1, c-1) || checkDiagonal(r-1, c+1) ||
			    checkDiagonal(r+1, c-1) || checkDiagonal(r+1, c+1))
			{
				touchesCorner = true;
			}
		}
		if (!touchesCorner) return false;

		for (int[] sq : shape)
		{
			int r = row + sq[0], c = col + sq[1];
			if (checkSide(r-1, c) || checkSide(r+1, c) ||
			    checkSide(r, c-1) || checkSide(r, c+1))
			{
				return false;
			}
		}
		return true;
	}

	private boolean checkDiagonal(int r, int c)
	{
		if (r < 0 || r >= boardSize || c < 0 || c >= boardSize) return false;
		return boardSquares[r][c].hasPlayer(currentPlayer);
	}

	private boolean checkSide(int r, int c)
	{
		if (r < 0 || r >= boardSize || c < 0 || c >= boardSize) return false;
		return boardSquares[r][c].hasPlayer(currentPlayer);
	}

	public int[][] getPieceShape()
	{
		int[][] base    = getBaseShape();
		int[][] rotated = new int[base.length][2];

		for (int i = 0; i < base.length; i++)
		{
			int r = base[i][0], c = base[i][1];
			for (int rot = 0; rot < pieceRotation; rot++)
			{
				int newR = c, newC = -r;
				r = newR; c = newC;
			}
			rotated[i] = new int[]{r, c};
		}

		int minR = Integer.MAX_VALUE, minC = Integer.MAX_VALUE;
		for (int[] sq : rotated)
		{
			minR = Math.min(minR, sq[0]);
			minC = Math.min(minC, sq[1]);
		}
		for (int[] sq : rotated)
		{
			sq[0] -= minR;
			sq[1] -= minC;
		}

		// apply horizontal mirror if flipped
		if (pieceFlipped)
		{
			for (int[] sq : rotated) sq[1] = -sq[1];
			int minC2 = Integer.MAX_VALUE;
			for (int[] sq : rotated) minC2 = Math.min(minC2, sq[1]);
			for (int[] sq : rotated) sq[1] -= minC2;
		}

		return rotated;
	}

	public int[][] getBaseShape()
	{
		switch (selectedPieceType)
		{
			case "I1": return new int[][]{{0,0}};
			case "I2": return new int[][]{{0,0},{0,1}};
			case "I3": return new int[][]{{0,0},{0,1},{0,2}};
			case "V3": return new int[][]{{0,0},{0,1},{1,0}};
			case "I4": return new int[][]{{0,0},{0,1},{0,2},{0,3}};
			case "O":  return new int[][]{{0,0},{0,1},{1,0},{1,1}};
			case "T":  return new int[][]{{0,0},{0,1},{0,2},{1,1}};
			case "L4": return new int[][]{{0,0},{1,0},{2,0},{2,1}};
			case "Z4": return new int[][]{{0,0},{0,1},{1,1},{1,2}};
			case "F":  return new int[][]{{0,1},{0,2},{1,0},{1,1},{2,1}};
			case "I5": return new int[][]{{0,0},{0,1},{0,2},{0,3},{0,4}};
			case "L":  return new int[][]{{0,0},{1,0},{2,0},{3,0},{3,1}};
			case "N":  return new int[][]{{0,1},{1,0},{1,1},{2,0},{3,0}};
			case "P":  return new int[][]{{0,0},{0,1},{1,0},{1,1},{2,0}};
			case "T5": return new int[][]{{0,0},{0,1},{0,2},{1,1},{2,1}};
			case "U":  return new int[][]{{0,0},{0,2},{1,0},{1,1},{1,2}};
			case "V":  return new int[][]{{0,0},{1,0},{2,0},{2,1},{2,2}};
			case "W":  return new int[][]{{0,0},{1,0},{1,1},{2,1},{2,2}};
			case "X":  return new int[][]{{0,1},{1,0},{1,1},{1,2},{2,1}};
			case "Y":  return new int[][]{{0,1},{1,0},{1,1},{2,1},{3,1}};
			case "Z":  return new int[][]{{0,0},{0,1},{1,1},{2,1},{2,2}};
			default:   return new int[][]{{0,0}};
		}
	}

	public void restoreState(GameSaveState state)
	{
		this.numberOfPlayers = state.numberOfPlayers;
		this.playerNames     = state.playerNames;
		this.colorOwners     = state.colorOwners;

		if (state.isHuman != null)
		{
			this.players = new Player[state.numberOfPlayers];
			for (int i = 0; i < state.numberOfPlayers; i++)
			{
				String diff = (state.difficulties != null) ? state.difficulties[i] : "Easy";
				if (state.isHuman[i])
					this.players[i] = new Player(i + 1, true);
				else
					this.players[i] = new ComputerPlayer(i + 1, diff, this);
			}
		}

		for (int r = 0; r < boardSize; r++)
		{
			for (int c = 0; c < boardSize; c++)
			{
				boardSquares[r][c].setEnabled(true);
				int occupant = state.boardState[r][c];
				if (occupant == 0)
					boardSquares[r][c].setEmpty();
				else
				{
					boardSquares[r][c].setPlayer(occupant);
					boardSquares[r][c].setEnabled(false);
				}
			}
		}

		this.piecesUsed          = state.piecesUsed;
		this.hasPlacedFirstPiece = state.hasPlacedFirstPiece;
		this.lastPieceWasMono    = state.lastPieceWasMono;
		this.currentPlayer       = state.currentPlayer;
		this.consecutivePasses   = state.consecutivePasses;
		this.gameActive          = true;

		selectedPieceIndex = 0;
		selectedPieceType  = PIECE_IDS[0];
		pieceRotation      = 0;

		updatePieceButtons();
		statusLabel.setText(getColorDisplayName(currentPlayer) + " - Select piece (game loaded)");
		triggerComputerTurnIfNeeded();
	}

	private static String[] buildPlayerNames(int n)
	{
		String[] names = new String[n];
		for (int i = 0; i < n; i++) names[i] = "Player " + (i + 1);
		return names;
	}
}