import java.io.*;
import javax.swing.*;

public class SaveLoadManager
{
    private static final String SAVE_FILE = "blokus_save.dat";

    public static boolean hasSaveFile()
    {
        return new File(SAVE_FILE).exists();
    }

    public static void saveGame(BlokusGame game)
    {
        GameSaveState state = buildState(game);
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(SAVE_FILE)))
        {
            out.writeObject(state);
            JOptionPane.showMessageDialog(game, "Game saved successfully!", "Saved", JOptionPane.INFORMATION_MESSAGE);
        }
        catch (IOException e)
        {
            JOptionPane.showMessageDialog(game, "Could not save the game:\n" + e.getMessage(), "Save Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static boolean loadIntoGame(BlokusGame game)
    {
        if (!hasSaveFile())
        {
            JOptionPane.showMessageDialog(game, "No saved game found.", "Load", JOptionPane.INFORMATION_MESSAGE);
            return false;
        }
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(SAVE_FILE)))
        {
            GameSaveState state = (GameSaveState) in.readObject();
            game.restoreState(state);
            return true;
        }
        catch (Exception e)
        {
            JOptionPane.showMessageDialog(game, "Could not load the saved game:\n" + e.getMessage(), "Load Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }

    public static BlokusGame createGameFromSave()
    {
        if (!hasSaveFile()) return null;
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(SAVE_FILE)))
        {
            GameSaveState state = (GameSaveState) in.readObject();
            return new BlokusGame(state);
        }
        catch (Exception e)
        {
            System.err.println("SaveLoadManager: could not read save - " + e.getMessage());
            return null;
        }
    }

    public static void deleteSave()
    {
        new File(SAVE_FILE).delete();
    }

    private static GameSaveState buildState(BlokusGame game)
    {
        GameSaveState s = new GameSaveState();

        s.boardSize  = game.boardSize;
        s.boardState = new int[game.boardSize][game.boardSize];
        for (int r = 0; r < game.boardSize; r++)
            for (int c = 0; c < game.boardSize; c++)
                s.boardState[r][c] = game.boardSquares[r][c].getOccupiedBy();

        s.piecesUsed          = deepCopy(game.piecesUsed);
        s.hasPlacedFirstPiece = game.hasPlacedFirstPiece.clone();
        s.lastPieceWasMono    = game.lastPieceWasMono.clone();
        s.currentPlayer       = game.currentPlayer;
        s.consecutivePasses   = game.consecutivePasses;
        s.numberOfPlayers     = game.numberOfPlayers;
        s.playerNames         = game.playerNames  != null ? game.playerNames.clone()  : null;
        s.colorOwners         = game.colorOwners  != null ? game.colorOwners.clone()  : null;

        if (game.players != null)
        {
            int n = game.players.length;
            s.isHuman      = new boolean[n];
            s.difficulties = new String[n];
            for (int i = 0; i < n; i++)
            {
                if (game.players[i] != null)
                {
                    s.isHuman[i]      = game.players[i].isHuman();
                    s.difficulties[i] = game.players[i].getDifficulty();
                }
                else
                {
                    s.isHuman[i]      = true;
                    s.difficulties[i] = "Easy";
                }
            }
        }
        return s;
    }

    private static boolean[][] deepCopy(boolean[][] src)
    {
        boolean[][] copy = new boolean[src.length][];
        for (int i = 0; i < src.length; i++) copy[i] = src[i].clone();
        return copy;
    }
}