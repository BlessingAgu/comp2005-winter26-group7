public class MainMenu {
    public static void main(String[] args) throws Exception {
        System.out.println("Hello, World!");
        MainMenuUi mainMenuUi = new MainMenuUi();
        
    }
}