import java.util.ArrayList;
import java.util.Random;

public class ComputerPlayer extends Player {

    private Random random = new Random(); // for choosing random position on the board when i code it
    public BlokusGame game; // reference to the game board so we can read state and place pieces

    public ComputerPlayer(int playerNumber, String difficulty, BlokusGame game) {
        super(playerNumber, false); // always not human
        setDifficulty(difficulty);
        this.game = game; // save the game reference so the methods below can use it
    }

    // called when it's the computer player's turn, checks the difficulty and calls the right method
    public void takeTurn() {
        if (getDifficulty().equals("Easy")) {
            easyMove();
        } else {
            hardMove();
        }
    }

    // not void because it needs to return the list back to whenever its called
    private ArrayList<int[]> getValidMoves() { 
        // creates a list to store all valid moves
        // each move is stored as {row, col, rotation}
        ArrayList<int[]> moves = new ArrayList<>();

        // loop through every square on the board (20x20 = 400 squares)
        for (int row = 0; row < game.boardSize; row++) {
            for (int col = 0; col < game.boardSize; col++) {

                // try all 4 rotations and both flip states (8 orientations total)
                for (int rot = 0; rot < 4; rot++) {
                    for (int flip = 0; flip < 2; flip++) {
                        game.pieceRotation = rot;
                        game.pieceFlipped  = (flip == 1);

                        int[][] shape = game.getPieceShape();

                        if (game.canPlacePiece(row, col, shape)) {
                            // store row, col, rotation, and flip state
                            moves.add(new int[]{row, col, rot, flip});
                        }
                    }
                }
            }
        }
        return moves; // returns the list to be used by other methods (easyMove and hardMove)
    }

    // takes the list of valid moves and picks one at random to place
    // passing in chosenPieceIndex so it knows which piece it's placing
    private void placeRandomMove(ArrayList<int[]> moves, int chosenPieceIndex) {
        // pick a random valid move
        if (moves.size() > 0) {
            // pick a random index number between 0 and however many moves we found
            int randomChoice = random.nextInt(moves.size());
            
            // grab the chosen move's data, it's row, column, and rotation
            int[] chosenMove = moves.get(randomChoice);
            int chosenRow  = chosenMove[0];
            int chosenCol  = chosenMove[1];
            int chosenRot  = chosenMove[2];
            int chosenFlip = chosenMove[3];

            game.selectedPieceIndex = chosenPieceIndex;
            game.selectedPieceType  = BlokusGame.PIECE_IDS[chosenPieceIndex];
            game.pieceRotation      = chosenRot;
            game.pieceFlipped       = (chosenFlip == 1);

            // gets the final shape with the correct piece and rotation set
            int[][] finalShape = game.getPieceShape();

            // loop through each square of the piece shape and color it on the board
            // sq[0] is the row offset, sq[1] is the col offset from the chosen position
            // basically: relative to where has been clicked, also fill in the remaining squares of the piece
            for (int[] sq : finalShape) {
                int r = chosenRow + sq[0];
                int c = chosenCol + sq[1];

                // BUG FIX: use game.currentPlayer (the color number) not getPlayerNumber()
                // In 2/3-player games a player controls multiple colors, so these differ.
                // e.g. Player 1 controls colors 1 AND 3 — when playing color 3 we must
                // pass 3 to setPlayer(), not 1, otherwise the square paints the wrong color.
                game.boardSquares[r][c].setPlayer(game.currentPlayer);

                // lock the square so nobody can click it again
                game.boardSquares[r][c].setEnabled(false);
            }
        }
    }

    // updates all the game state after the computer places a piece
    private void updateGameState(int pIndex, int chosenPieceIndex) {

        // update game state to end turn
        game.consecutivePasses = 0; // reset pass counter since a piece was placed
        game.piecesUsed[pIndex][chosenPieceIndex] = true; // piece is used
        game.hasPlacedFirstPiece[pIndex] = true; // so it checks off that it touched the corner
        game.lastPieceWasMono[pIndex] = (chosenPieceIndex == 0);
        game.pieceRotation = 0; // reset rotation and flip back to default
        game.pieceFlipped  = false;

        // goes to the next player
        // if player 1 just went 1 % 4 = 1, then 1+1 = 2, player 2 goes next.
        // if player 3 just went, 3 % 4 = 3, then 3+1 = 4, so player 4 goes next.
        game.currentPlayer = (game.currentPlayer % 4) + 1;

        // reset piece selection and refresh buttons for next player (so it isn't using the last piece the computer player used)
        game.selectedPieceIndex = 0;
        game.selectedPieceType = BlokusGame.PIECE_IDS[0];
        game.updatePieceButtons();
        game.statusLabel.setText(game.getColorDisplayName(game.currentPlayer) + " - Select piece");

        // check if next player is a computer, if so take their turn automatically
        game.triggerComputerTurnIfNeeded();
    }

    // EASY - smallest piece first, random legal position
    // BUG FIX: old code only tried ONE piece. If that piece had no valid placements
    // it silently returned — CPU would freeze on its turn forever.
    // Now we loop through ALL pieces from smallest to largest until one fits.
    // If nothing fits at all, we auto-pass so the game keeps moving.
    private void easyMove() {
        int pIndex = game.currentPlayer - 1;

        // try pieces from smallest (index 0) to largest (index 20)
        for (int i = 0; i < 21; i++) {
            if (game.piecesUsed[pIndex][i]) continue; // already used, skip

            // set this piece as selected so getValidMoves() and canPlacePiece() check it
            game.selectedPieceIndex = i;
            game.selectedPieceType = BlokusGame.PIECE_IDS[i];

            ArrayList<int[]> validMoves = getValidMoves();

            if (validMoves.size() > 0) {
                placeRandomMove(validMoves, i);
                updateGameState(pIndex, i);
                return; // placed successfully, done
            }
        }

        // no piece could be placed — auto-pass so the game doesn't freeze
        game.passTurn();
    }
    

    // HARD - biggest piece first, random legal position
    // Now loops from largest to smallest, auto-passes if nothing can be placed.
    private void hardMove() {
        int pIndex = game.currentPlayer - 1;

        // try pieces from largest (index 20) to smallest (index 0)
        for (int i = 20; i >= 0; i--) {
            if (game.piecesUsed[pIndex][i]) continue;

            game.selectedPieceIndex = i;
            game.selectedPieceType = BlokusGame.PIECE_IDS[i];

            ArrayList<int[]> validMoves = getValidMoves();

            if (validMoves.size() > 0) {
                placeRandomMove(validMoves, i);
                updateGameState(pIndex, i);
                return;
            }
        }

        // no piece could be placed — auto-pass
        game.passTurn();
    }
}