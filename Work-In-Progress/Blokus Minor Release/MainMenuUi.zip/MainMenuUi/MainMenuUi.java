import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MainMenuUi implements ActionListener {

    JFrame frame= new JFrame("Main Menu");
    JButton startButton, loadGame, gameRules, exitButton;
    JFrame frame2 = new JFrame("Rules");
    
    public MainMenuUi(){

        //main frame
        frame.setSize(800,600);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);
        frame.setLayout(new BorderLayout());

        //adding background image, make sure the image is in right path
        ImageIcon bgPicture = new ImageIcon((getClass().getResource("/blokus.png")));;
        frame.add(new JLabel(bgPicture), BorderLayout.CENTER);  
        
        // adding a button panel at the bottom of frame then adding buttons to the panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        startButton = new JButton("Start Game");
        startButton.setPreferredSize(new Dimension(100, 50));
        startButton.addActionListener(this);
        startButton.setFocusPainted(false);
        loadGame = new JButton("Load Game");
        loadGame.setPreferredSize(new Dimension(100, 50));
        loadGame.addActionListener(this);
        loadGame.setFocusPainted(false);
        gameRules = new JButton("Rules");
        gameRules.setPreferredSize(new Dimension(100, 50));
        gameRules.addActionListener(this);
        gameRules.setFocusPainted(false);
        exitButton = new JButton("Exit");
        exitButton.setPreferredSize(new Dimension(100, 50));
        exitButton.addActionListener(this);
        exitButton.setFocusPainted(false);
        
        buttonPanel.add(startButton);
        buttonPanel.add(loadGame);
        buttonPanel.add(gameRules);
        buttonPanel.add(exitButton);
        frame.add(buttonPanel, BorderLayout.SOUTH);


        frame.setVisible(true);
       
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()== startButton){
            System.out.println("Start Game button clicked!");   
        }
        if(e.getSource() == loadGame){
            System.out.println("Initiate your load game here! and Check if a load game file exists once a object is created!");
        }

        if(e.getSource() == gameRules){

            frame2.setSize(800,600);
            frame2.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            frame2.setLocationRelativeTo(null);
            
            JTextArea rulesText = new JTextArea();
            rulesText.setEditable(false);
            rulesText.setBackground(Color.BLACK);
            rulesText.setForeground(Color.GREEN);
            rulesText.setCaretColor(Color.BLACK);
            rulesText.setFont(new Font("Consolas", Font.BOLD,20));
            rulesText.setLineWrap(true);
            rulesText.setMargin(new Insets(20, 20, 20, 20));
            rulesText.setText(" Rule 1: Place maximum numbers of pieces\n" + 
            " Rule 2: For first piece, you must place it in a corner\n" + 
            " Rule 3: For next pieces, you must touch a corner of your own pieces\n" +
            " Rule 4: You cannot place a piece where there are other pieces \n" + 
            " Rule 5: At the end, the person with fewest pieces left wins! \n" + "\n That's it!! Enjoy!!\n" );

            frame2.add(rulesText);
            frame2.setVisible(true);

        }
        if(e.getSource() == exitButton){
            System.exit(0);

        }
    }
}