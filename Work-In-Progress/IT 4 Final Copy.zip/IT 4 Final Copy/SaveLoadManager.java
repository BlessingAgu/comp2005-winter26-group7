import java.io.*;
import javax.swing.*;

public class SaveLoadManager
{
    private static final String SAVE_FILE = "blokus_save.dat";

    public static boolean hasSaveFile()
    {
        return new File(SAVE_FILE).exists();
    }

    public static void saveGame(BlokusGame game)
    {
        GameSaveState state = buildState(game);
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(SAVE_FILE)))
        {
            out.writeObject(state);
            JOptionPane.showMessageDialog(game, "Game saved successfully!", "Saved", JOptionPane.INFORMATION_MESSAGE);
        }
        catch (IOException e)
        {
            JOptionPane.showMessageDialog(game, "Could not save the game:\n" + e.getMessage(), "Save Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static boolean loadIntoGame(BlokusGame game)
    {
        if (!hasSaveFile())
        {
            JOptionPane.showMessageDialog(game, "No saved game found.", "Load", JOptionPane.INFORMATION_MESSAGE);
            return false;
        }
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(SAVE_FILE)))
        {
            GameSaveState state = (GameSaveState) in.readObject();
            game.restoreState(state);
            return true;
        }
        catch (Exception e)
        {
            JOptionPane.showMessageDialog(game, "Could not load the saved game:\n" + e.getMessage(), "Load Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }

    public static BlokusGame createGameFromSave()
    {
        if (!hasSaveFile()) return null;
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(SAVE_FILE)))
        {
            GameSaveState state = (GameSaveState) in.readObject();
            return new BlokusGame(state);
        }
        catch (Exception e)
        {
            System.err.println("SaveLoadManager: could not read save - " + e.getMessage());
            return null;
        }
    }

    public static void deleteSave()
    {
        new File(SAVE_FILE).delete();
    }

    private static GameSaveState buildState(BlokusGame game)
    {
        GameSaveState s = new GameSaveState();

        s.boardSize  = game.getBoardSize();
        s.boardState = new int[game.getBoardSize()][game.getBoardSize()];
        for (int r = 0; r < game.getBoardSize(); r++)
            for (int c = 0; c < game.getBoardSize(); c++)
                s.boardState[r][c] = game.getSquare(r, c).getOccupiedBy();

        s.piecesUsed          = deepCopy(game.getPiecesUsed());
        s.hasPlacedFirstPiece = game.getHasPlacedFirstPiece().clone();
        s.lastPieceWasMono    = game.getLastPieceWasMono().clone();
        s.currentPlayer       = game.getCurrentPlayer();
        s.consecutivePasses   = game.getConsecutivePasses();
        s.numberOfPlayers     = game.getNumberOfPlayers();
        s.playerNames         = game.getPlayerNames() != null ? game.getPlayerNames().clone() : null;
        s.colorOwners         = game.getColorOwners() != null ? game.getColorOwners().clone() : null;

        if (game.getPlayers() != null)
        {
            int n = game.getPlayers().length;
            s.isHuman      = new boolean[n];
            s.difficulties = new String[n];
            for (int i = 0; i < n; i++)
            {
                if (game.getPlayer(i) != null)
                {
                    s.isHuman[i]      = game.getPlayer(i).isHuman();
                    s.difficulties[i] = game.getPlayer(i).getDifficulty();
                }
                else
                {
                    s.isHuman[i]      = true;
                    s.difficulties[i] = "Easy";
                }
            }
        }
        return s;
    }

    private static boolean[][] deepCopy(boolean[][] src)
    {
        boolean[][] copy = new boolean[src.length][];
        for (int i = 0; i < src.length; i++) copy[i] = src[i].clone();
        return copy;
    }
}