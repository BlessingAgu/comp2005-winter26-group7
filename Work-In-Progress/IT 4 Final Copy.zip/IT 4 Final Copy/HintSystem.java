import java.awt.Color;
import javax.swing.Timer;
import java.util.ArrayList;

public class HintSystem {

    private static Timer blinkTimer; // keeps track of the blink so we can stop it

    // called when the hint button is clicked
    public static void showHint(BlokusGame game) {

        // hints must be enabled in options to work
        if (!GameActions.areHintsEnabled()) return;

        // stop any existing hint before showing a new one
        clearHint(game);

        // create a temporary computer player just to find valid moves
        // reuses the same logic as the computer player without duplicating code
        ComputerPlayer temp = new ComputerPlayer(game.getCurrentPlayer(), "Easy", game);
        ArrayList<int[]> moves = temp.getValidMoves();

        // no valid moves found for this piece, nothing to show
        if (moves.isEmpty()) return;

        // grab the first valid move from the list
        int hintRow = moves.get(0)[0];
        int hintCol = moves.get(0)[1];
        int hintRot = moves.get(0)[2]; // the rotation that works

        // tell BlokusGame which square to protect from clearPreview
        game.setHintPosition(hintRow, hintCol);

        // tell the player where to place and what rotation to use
        game.setStatusText("Hint: Rotate " + (hintRot * 90) + "° then place on highlighted square");
        game.setHintActive(true);

        // use a light version of the current player's color for the blink
        Color playerColor = BoardSquareColors.getLightColorForPlayer(game.getCurrentPlayer());

        // blink the square on and off every 400ms
        blinkTimer = new Timer(400, null);
        blinkTimer.addActionListener(e -> {
            if (game.getSquare(hintRow, hintCol).getBackground().equals(Color.WHITE)) {
                // square is white, light it up with player color
                game.getSquare(hintRow, hintCol).setBackground(playerColor);
                game.getSquare(hintRow, hintCol).repaint();
            } else {
                // square is colored, turn it back to white
                game.getSquare(hintRow, hintCol).setBackground(Color.WHITE);
                game.getSquare(hintRow, hintCol).repaint();
            }
        });
        blinkTimer.start();
    }

    // stops any active hint and resets squares back to white
    public static void clearHint(BlokusGame game) {
        game.setHintActive(false); // tell BlokusGame hint is no longer active
        game.setHintPosition(-1, -1); // reset hint position
        game.clearRotationLabel();
        if (blinkTimer != null) { blinkTimer.stop(); blinkTimer = null; }

        // reset all empty squares back to white
        for (int row = 0; row < game.getBoardSize(); row++)
            for (int col = 0; col < game.getBoardSize(); col++)
                if (game.getSquare(row, col).isEmpty())
                    game.getSquare(row, col).setBackground(Color.WHITE);
    }
}