import java.util.ArrayList;
import java.util.Random;

public class ComputerPlayer extends Player {

    private Random random = new Random(); // for choosing random position on the board
    private BlokusGame game; // reference to the game board so we can read state and place pieces

    public ComputerPlayer(int playerNumber, String difficulty, BlokusGame game) {
        super(playerNumber, false); // always not human
        setDifficulty(difficulty);
        this.game = game; // save the game reference so the methods below can use it
    }

    // called when it's the computer player's turn, checks the difficulty and calls the right method
    public void takeTurn() {
        if (getDifficulty().equals("Easy")) {
            easyMove();
        } else {
            hardMove();
        }
    }

    // not void because it needs to return the list back to whenever its called
    // now public so HintSystem can reuse it to find valid moves for hints
    public ArrayList<int[]> getValidMoves() {
        // creates a list to store all valid moves
        // each move is stored as {row, col, rotation, flip}
        ArrayList<int[]> moves = new ArrayList<>();

        // loop through every square on the board (20x20 = 400 squares)
        for (int row = 0; row < game.getBoardSize(); row++) {
            for (int col = 0; col < game.getBoardSize(); col++) {

                // try all 4 rotations and both flip states (8 orientations total)
                for (int rot = 0; rot < 4; rot++) {
                    for (int flip = 0; flip < 2; flip++) {
                        game.setPieceRotation(rot);
                        game.setPieceFlipped(flip == 1);

                        int[][] shape = game.getPieceShape();

                        if (game.canPlacePiece(row, col, shape)) {
                            // legal move found, store row, col, rotation, and flip state
                            moves.add(new int[]{row, col, rot, flip});
                        }
                    }
                }
            }
        }
        return moves; // returns the list to be used by other methods (easyMove and hardMove)
    }

    // takes the list of valid moves and picks one at random to place
    // passing in chosenPieceIndex so it knows which piece it's placing
    private void placeRandomMove(ArrayList<int[]> moves, int chosenPieceIndex) {
        if (moves.size() > 0) {
            // pick a random index number between 0 and however many moves we found
            int randomChoice = random.nextInt(moves.size());

            // grab the chosen move's data, its row, column, rotation and flip
            int[] chosenMove = moves.get(randomChoice);
            int chosenRow  = chosenMove[0];
            int chosenCol  = chosenMove[1];
            int chosenRot  = chosenMove[2];
            int chosenFlip = chosenMove[3];

            // make sure the right piece, rotation and flip are set before getting the shape
            // without this, getPieceShape() might return the wrong shape
            game.setSelectedPiece(chosenPieceIndex, BlokusGame.PIECE_IDS[chosenPieceIndex]);
            game.setPieceRotation(chosenRot);
            game.setPieceFlipped(chosenFlip == 1);

            // gets the final shape with the correct piece, rotation and flip set
            int[][] finalShape = game.getPieceShape();

            // loop through each square of the piece shape and color it on the board
            // sq[0] is the row offset, sq[1] is the col offset from the chosen position
            // basically: relative to where its been placed, also fill in the remaining squares
            for (int[] sq : finalShape) {
                int r = chosenRow + sq[0];
                int c = chosenCol + sq[1];

                // use getCurrentPlayer() (the color slot) not getPlayerNumber()
                // in 2/3 player games a player controls multiple colors so these differ
                // e.g. player 1 controls colors 1 AND 3 - when playing color 3 we must
                // pass 3 to setPlayer(), not 1, otherwise the square paints the wrong color
                game.setSquarePlayer(r, c, game.getCurrentPlayer());

                // lock the square so nobody can click it again
                game.setSquareEnabled(r, c, false);
            }
        }
    }

    // updates all the game state after the computer places a piece
    private void updateGameState(int pIndex, int chosenPieceIndex) {

        game.resetConsecutivePasses();
        game.setPieceUsed(pIndex, chosenPieceIndex);
        game.setHasPlacedFirst(pIndex);
        game.setLastPieceWasMono(pIndex, chosenPieceIndex == 0);

        // reset rotation and flip back to default
        game.setPieceRotation(0);
        game.setPieceFlipped(false);

        // advance to the next color slot
        // if slot 1 just went: 1 % 4 = 1, then 1+1 = 2, slot 2 goes next
        // if slot 4 just went: 4 % 4 = 0, then 0+1 = 1, back to slot 1
        game.setCurrentPlayer((game.getCurrentPlayer() % 4) + 1);

        // advance slot 4 rotation in 3 player mode
        if (game.getNumberOfPlayers() == 3 && game.getCurrentPlayer() == 1)
        {
            game.advanceSlot4();
        }

        // reset piece selection for next player so it isnt using the last piece the computer used
        game.setSelectedPiece(0, BlokusGame.PIECE_IDS[0]);
        game.updatePieceButtons();
        game.setStatusText(game.getColorDisplayName(game.getCurrentPlayer()) + " - Select piece");

        // check if next player is a computer, if so take their turn automatically
        game.triggerComputerTurnIfNeeded();
    }

    // EASY - smallest piece first, random legal position
    // loops through ALL pieces from smallest to largest until one fits
    // if nothing fits at all, auto-passes so the game keeps moving
    private void easyMove() {
        int pIndex = game.getCurrentPlayer() - 1;

        // try pieces from smallest (index 0) to largest (index 20)
        for (int i = 0; i < 21; i++) {
            if (game.isPieceUsed(pIndex, i)) continue; // already used, skip

            // set this piece as selected so getValidMoves() checks it
            game.setSelectedPiece(i, BlokusGame.PIECE_IDS[i]);

            ArrayList<int[]> validMoves = getValidMoves();

            if (validMoves.size() > 0) {
                placeRandomMove(validMoves, i);
                updateGameState(pIndex, i);
                return; // placed successfully, done
            }
        }

        // no piece could be placed, auto-pass so the game doesnt freeze
        game.passTurn();
    }

    // HARD - biggest piece first, random legal position
    // loops from largest to smallest, auto-passes if nothing can be placed
    private void hardMove() {
        int pIndex = game.getCurrentPlayer() - 1;

        // try pieces from largest (index 20) to smallest (index 0)
        for (int i = 20; i >= 0; i--) {
            if (game.isPieceUsed(pIndex, i)) continue; // already used, skip

            // set this piece as selected so getValidMoves() checks it
            game.setSelectedPiece(i, BlokusGame.PIECE_IDS[i]);

            ArrayList<int[]> validMoves = getValidMoves();

            if (validMoves.size() > 0) {
                placeRandomMove(validMoves, i);
                updateGameState(pIndex, i);
                return; // placed successfully, done
            }
        }

        // no piece could be placed, auto-pass so the game doesnt freeze
        game.passTurn();
    }

    // lets BlokusGame set the game reference after construction
    public void setGame(BlokusGame game) {
        this.game = game;
    }
}