import java.awt.*;
import javax.swing.*;

public class setUpGame extends JFrame {

    private int numberOfPlayers;
    private Player[] players = new Player[4];
    private int[] playerColorChoice = {1, 2, 3, 4};

    private JButton player1Button;
    private JButton player2Button;
    private JButton player3Button;
    private JButton player4Button;

    private JButton swatch1;
    private JButton swatch2;
    private JButton swatch3;
    private JButton swatch4;

    private JPanel row1;
    private JPanel row2;
    private JPanel row3;
    private JPanel row4;

    public setUpGame() {
        numberOfPlayers = 2;
        players[0] = new Player(1, true);
        players[1] = new Player(2, true);

        setTitle("Game Set Up");
        setSize(560, 440);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));

        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        JButton back = new JButton("Main Menu");
        back.addActionListener(e -> { dispose(); new MainMenuUi(); });
        JButton start = new JButton("Start Game");
        start.addActionListener(e -> startGame());
        topPanel.add(back);
        topPanel.add(start);
        add(topPanel, BorderLayout.NORTH);

        JPanel playerPanel = new JPanel(new GridLayout(4, 1, 8, 8));
        playerPanel.setBorder(BorderFactory.createEmptyBorder(5, 30, 5, 30));

        player1Button = new JButton("Player 1 - Human (locked)");
        player1Button.setFont(new Font("Arial", Font.BOLD, 14));
        player1Button.setEnabled(false);
        swatch1 = makeSwatchButton(1, 0);
        row1 = makeRow(player1Button, swatch1);
        playerPanel.add(row1);

        player2Button = new JButton("Player 2 - Choose Player");
        player2Button.setFont(new Font("Arial", Font.BOLD, 14));
        player2Button.addActionListener(e -> openChangeTypeDialog(1, player2Button));
        swatch2 = makeSwatchButton(2, 1);
        row2 = makeRow(player2Button, swatch2);
        playerPanel.add(row2);

        player3Button = new JButton("Player 3 - Choose Player");
        player3Button.setFont(new Font("Arial", Font.BOLD, 14));
        player3Button.addActionListener(e -> openChangeTypeDialog(2, player3Button));
        swatch3 = makeSwatchButton(3, 2);
        row3 = makeRow(player3Button, swatch3);
        row3.setVisible(false);
        playerPanel.add(row3);

        player4Button = new JButton("Player 4 - Choose Player");
        player4Button.setFont(new Font("Arial", Font.BOLD, 14));
        player4Button.addActionListener(e -> openChangeTypeDialog(3, player4Button));
        swatch4 = makeSwatchButton(4, 3);
        row4 = makeRow(player4Button, swatch4);
        row4.setVisible(false);
        playerPanel.add(row4);

        add(playerPanel, BorderLayout.CENTER);

        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 10));
        JButton addPlayerButton = new JButton("Add Player");
        addPlayerButton.addActionListener(e -> addPlayer());
        JButton removePlayerButton = new JButton("Remove Player");
        removePlayerButton.addActionListener(e -> removePlayer());
        JButton optionsButton = new JButton("Options");
        optionsButton.addActionListener(e -> new OptionsMenu(this));
        bottomPanel.add(addPlayerButton);
        bottomPanel.add(removePlayerButton);
        bottomPanel.add(optionsButton);
        add(bottomPanel, BorderLayout.SOUTH);

        setLocationRelativeTo(null);
        setVisible(true);
    }

    private JPanel makeRow(JButton typeButton, JButton swatch) {
        JPanel row = new JPanel(new BorderLayout(6, 0));
        row.add(typeButton, BorderLayout.CENTER);
        row.add(swatch, BorderLayout.EAST);
        return row;
    }

    private JButton makeSwatchButton(int colorNumber, int slotIndex) {
        JButton btn = new JButton("<html><center>Pick<br>Color</center></html>");
        btn.setPreferredSize(new Dimension(90, 55));
        btn.setBackground(BoardSquareColors.getColorForPlayer(colorNumber));
        btn.setForeground(Color.BLACK);
        btn.setFont(new Font("Arial", Font.BOLD, 12));
        btn.setOpaque(true);
        btn.setBorderPainted(true);
        btn.setFocusPainted(false);
        btn.addActionListener(e -> openColorPickerDialog(slotIndex));
        return btn;
    }

    private void openColorPickerDialog(int slotIndex) {
        JDialog dialog = new JDialog(this, "Pick Your Color - Player " + (slotIndex + 1), true);
        dialog.setSize(320, 130);
        dialog.setLayout(new BorderLayout(6, 6));
        dialog.getRootPane().setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JPanel colorRow = new JPanel(new GridLayout(1, 4, 8, 0));

        for (int colorNum = 1; colorNum <= 4; colorNum++) {
            final int c = colorNum;
            JButton colorBtn = new JButton();
            colorBtn.setPreferredSize(new Dimension(60, 60));
            colorBtn.setBackground(BoardSquareColors.getColorForPlayer(colorNum));
            colorBtn.setOpaque(true);

            boolean takenByOther = false;
            for (int i = 0; i < numberOfPlayers; i++) {
                if (i != slotIndex && playerColorChoice[i] == colorNum) {
                    takenByOther = true;
                    break;
                }
            }
            colorBtn.setEnabled(!takenByOther);

            if (playerColorChoice[slotIndex] == colorNum) {
                colorBtn.setBorder(BorderFactory.createLineBorder(Color.BLACK, 3));
                colorBtn.setToolTipText("Current color");
            } else if (takenByOther) {
                colorBtn.setToolTipText("Already taken");
            }

            colorBtn.addActionListener(e -> {
                playerColorChoice[slotIndex] = c;
                refreshSwatch(slotIndex, c);
                dialog.dispose();
            });

            colorRow.add(colorBtn);
        }

        dialog.add(colorRow, BorderLayout.CENTER);
        dialog.setLocationRelativeTo(this);
        dialog.setVisible(true);
    }

    private void refreshSwatch(int slotIndex, int colorNumber) {
        Color chosen = BoardSquareColors.getColorForPlayer(colorNumber);
        switch (slotIndex) {
            case 0: swatch1.setBackground(chosen); break;
            case 1: swatch2.setBackground(chosen); break;
            case 2: swatch3.setBackground(chosen); break;
            case 3: swatch4.setBackground(chosen); break;
        }
        repaint();
    }

    private void addPlayer() {
        if (numberOfPlayers >= 4) {
            JOptionPane.showMessageDialog(this,
                "Maximum 4 players allowed.", "Full", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        int slot = numberOfPlayers;
        players[slot] = new Player(slot + 1, true);
        numberOfPlayers++;

        switch (slot) {
            case 2:
                player3Button.setText("Player 3 - Choose Player");
                refreshSwatch(2, playerColorChoice[2]);
                row3.setVisible(true);
                break;
            case 3:
                player4Button.setText("Player 4 - Choose Player");
                refreshSwatch(3, playerColorChoice[3]);
                row4.setVisible(true);
                break;
        }
        revalidate();
        repaint();
    }

    private void removePlayer() {
        if (numberOfPlayers <= 2) {
            JOptionPane.showMessageDialog(this,
                "Minimum 2 players required.", "Cannot Remove", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        numberOfPlayers--;
        players[numberOfPlayers] = null;

        switch (numberOfPlayers) {
            case 2: row3.setVisible(false); break;
            case 3: row4.setVisible(false); break;
        }
        revalidate();
        repaint();
    }

    private void openChangeTypeDialog(int slotIndex, JButton button) {
        JDialog dialog = new JDialog(this, "Who is Player " + (slotIndex + 1) + "?", true);
        dialog.setSize(300, 180);
        dialog.setLayout(new GridLayout(3, 1, 8, 8));
        dialog.getRootPane().setBorder(BorderFactory.createEmptyBorder(12, 20, 12, 20));

        JButton humanBtn = new JButton("Human Player");
        JButton easyBtn  = new JButton("Computer (Easy)");
        JButton hardBtn  = new JButton("Computer (Hard)");

        humanBtn.addActionListener(e -> {
            players[slotIndex] = new Player(slotIndex + 1, true);
            button.setText("Player " + (slotIndex + 1) + " - Human");
            dialog.dispose();
        });
        easyBtn.addActionListener(e -> {
            players[slotIndex] = new ComputerPlayer(slotIndex + 1, "Easy", null);
            button.setText("Player " + (slotIndex + 1) + " - Computer (Easy)");
            dialog.dispose();
        });
        hardBtn.addActionListener(e -> {
            players[slotIndex] = new ComputerPlayer(slotIndex + 1, "Hard", null);
            button.setText("Player " + (slotIndex + 1) + " - Computer (Hard)");
            dialog.dispose();
        });

        dialog.add(humanBtn);
        dialog.add(easyBtn);
        dialog.add(hardBtn);
        dialog.setLocationRelativeTo(this);
        dialog.setVisible(true);
    }

    private void startGame() {
        if (numberOfPlayers < 2) {
            JOptionPane.showMessageDialog(this,
                "Please add at least 2 players before starting.",
                "Not Enough Players", JOptionPane.WARNING_MESSAGE);
            return;
        }

        for (int i = 0; i < numberOfPlayers; i++) {
            for (int j = i + 1; j < numberOfPlayers; j++) {
                if (playerColorChoice[i] == playerColorChoice[j]) {
                    JOptionPane.showMessageDialog(this,
                        "Player " + (i+1) + " and Player " + (j+1) +
                        " have the same color. Please choose different colors.",
                        "Same Color", JOptionPane.WARNING_MESSAGE);
                    return;
                }
            }
        }

        int[] colorOwners = new int[4];
        java.util.Arrays.fill(colorOwners, -1);
        for (int i = 0; i < numberOfPlayers; i++) {
            colorOwners[playerColorChoice[i] - 1] = i;
        }
        int nextPlayer = 0;
        for (int c = 0; c < 4; c++) {
            if (colorOwners[c] == -1) {
                colorOwners[c] = nextPlayer % numberOfPlayers;
                nextPlayer++;
            }
        }

        Player[] trimmed = new Player[numberOfPlayers];
        for (int i = 0; i < numberOfPlayers; i++) trimmed[i] = players[i];

        dispose();
        new BlokusGame(20, trimmed, numberOfPlayers, colorOwners);
    }

    public int getNumberOfPlayers() {
        return numberOfPlayers;
    }

    // refreshes all color swatches after palette change
    public void refreshSwatches()
    {
        // BoardSquareColors already updated by GameActions.colorMode()
        // just reread the colors for each player's current color choice
        swatch1.setBackground(BoardSquareColors.getColorForPlayer(playerColorChoice[0]));
        
        swatch2.setBackground(BoardSquareColors.getColorForPlayer(playerColorChoice[1]));
        
        swatch3.setBackground(BoardSquareColors.getColorForPlayer(playerColorChoice[2]));
        
        swatch4.setBackground(BoardSquareColors.getColorForPlayer(playerColorChoice[3]));
        repaint();
    }
}