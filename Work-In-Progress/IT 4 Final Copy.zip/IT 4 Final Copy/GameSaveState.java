import java.io.*;

public class GameSaveState implements Serializable
{
    private static final long serialVersionUID = 1L;

    public int boardSize;
    public int[][] boardState;

    public boolean[][] piecesUsed;
    public boolean[] hasPlacedFirstPiece;
    public boolean[] lastPieceWasMono;

    public int currentPlayer;
    public int consecutivePasses;

    public int numberOfPlayers;
    public String[] playerNames;
    public int[] colorOwners;

    public boolean[] isHuman;
    public String[] difficulties;
}